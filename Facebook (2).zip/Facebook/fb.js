function a(){
var email1=document.getElementById("email1").value;
var password1=document.getElementById("password1").value;
if( password1.length==0 || email1.length==0){
alert("Attenzione inserisci tutti i dati");
}else{
var conferma=confirm("Sei sicuro di voler inviare i tuoi dati?");
alert("I tuoi dati sono stati inviati");
return conferma;
}



}

function b(){
var nome=document.getElementById("nome").value;
var cognome=document.getElementById("cognome").value;
var email=document.getElementById("email").value;
var password=document.getElementById("password").value;
if(nome.length==0|| password.length==0 || email.length==0 || cognome.length==0){
alert("Attenzione inserisci tutti i dati");
}else{
var conferma=confirm("Sei sicuro di voler inviare i tuoi dati?");
alert("I tuoi dati sono stati inviati");
return conferma;
}



}

