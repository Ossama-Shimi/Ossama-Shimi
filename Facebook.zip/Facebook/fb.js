function a(){
	if(document.getElementById("email").value==""){
		alert("Attenzione, non hai inseito la tua email");
	} else if(document.getElementById("password").value==""){
		alert("Attenzione, non hai inseito la tua email");
	} else if(document.getElementById("nome").value==""){
		alert("Attenzione, non hai inseito il tuo nome");
	}else if(document.getElementById("cognome").value==""){
		alert("Attenzione, non hai inseito il tuo cognome");
	}